using sAPI.Models;
using System;

namespace sAPITest
{
    public class DummyDataDBInitializer
    {
        public DummyDataDBInitializer()
        {
        }

        public void Seed(SchDbContext context)
        {
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            context.Courses.AddRange(
                new Course() { CourseName = "CSHARP", StartDate = "12/12/2018", EndDate="12/05/2019" },
                new Course() { CourseName = "HND", StartDate = "11/10/2018", EndDate="05/03/2019" }
            );

            
            context.SaveChanges();
        }
    }
}